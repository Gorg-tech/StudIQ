var searchData=
[
  ['logging_5frunner_0',['logging_runner',['../namespacelogging__runner.html',1,'']]]
];
