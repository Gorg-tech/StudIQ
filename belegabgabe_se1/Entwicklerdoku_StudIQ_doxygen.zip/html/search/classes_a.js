var searchData=
[
  ['user_0',['User',['../classmodels_1_1User.html',1,'models']]],
  ['userrole_1',['UserRole',['../classmodels_1_1UserRole.html',1,'models']]],
  ['userserializer_2',['UserSerializer',['../classserializers_1_1UserSerializer.html',1,'serializers']]],
  ['userstatsview_3',['UserStatsView',['../classviews_1_1UserStatsView.html',1,'views']]]
];
