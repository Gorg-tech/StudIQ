var searchData=
[
  ['admin_0',['admin',['../namespaceadmin.html',1,'']]],
  ['apps_1',['apps',['../namespaceapps.html',1,'']]]
];
