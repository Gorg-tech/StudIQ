var searchData=
[
  ['registerserializer_0',['RegisterSerializer',['../classserializers_1_1RegisterSerializer.html',1,'serializers']]],
  ['registerview_1',['RegisterView',['../classviews_1_1RegisterView.html',1,'views']]]
];
