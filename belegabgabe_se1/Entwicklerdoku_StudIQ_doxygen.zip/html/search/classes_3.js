var searchData=
[
  ['feedback_0',['Feedback',['../classquizzes_1_1models_1_1Feedback.html',1,'quizzes::models']]],
  ['feedbackadmin_1',['FeedbackAdmin',['../classquizzes_1_1admin_1_1FeedbackAdmin.html',1,'quizzes::admin']]],
  ['feedbackserializer_2',['FeedbackSerializer',['../classquizzes_1_1serializers_1_1FeedbackSerializer.html',1,'quizzes::serializers']]],
  ['feedbackviewset_3',['FeedbackViewSet',['../classquizzes_1_1views_1_1FeedbackViewSet.html',1,'quizzes::views']]],
  ['friendrequestsview_4',['FriendRequestsView',['../classviews_1_1FriendRequestsView.html',1,'views']]],
  ['friendslistview_5',['FriendsListView',['../classviews_1_1FriendsListView.html',1,'views']]]
];
