var searchData=
[
  ['navigatetoitem_0',['navigateToItem',['../SearchView_8vue.html#a415455c425ed1d7417996b066063e98f',1,'SearchView.vue']]],
  ['normalizeitem_1',['normalizeItem',['../SearchView_8vue.html#ab56b2d555010cd66ca808cc5856d6dcc',1,'SearchView.vue']]]
];
