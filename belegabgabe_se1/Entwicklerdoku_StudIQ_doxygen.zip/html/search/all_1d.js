var searchData=
[
  ['–_20tt_20src_20client_20tt_0',['Frontend – &lt;tt&gt;src/client&lt;/tt&gt;',['../index.html#autotoc_md7',1,'']]],
  ['–_20tt_20src_20server_20tt_1',['Backend – &lt;tt&gt;src/server&lt;/tt&gt;',['../index.html#autotoc_md6',1,'']]]
];
