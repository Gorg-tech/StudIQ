var searchData=
[
  ['customuseradmin_0',['CustomUserAdmin',['../classadmin_1_1CustomUserAdmin.html',1,'admin']]]
];
