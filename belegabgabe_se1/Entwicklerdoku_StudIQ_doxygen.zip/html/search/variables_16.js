var searchData=
[
  ['zuordnung_0',['ZUORDNUNG',['../classquizzes_1_1models_1_1QuestionType.html#a18c3472b6efb3a5a5903d610c18c5c0f',1,'quizzes::models::QuestionType']]]
];
