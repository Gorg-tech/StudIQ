var searchData=
[
  ['0001_5finitial_2epy_0',['0001_initial.py',['../accounts_2migrations_20001__initial_8py.html',1,'(Global Namespace)'],['../quizzes_2migrations_20001__initial_8py.html',1,'(Global Namespace)']]],
  ['0002_5falter_5fquizattempt_5funique_5ftogether_5fand_5fmore_2epy_1',['0002_alter_quizattempt_unique_together_and_more.py',['../0002__alter__quizattempt__unique__together__and__more_8py.html',1,'']]],
  ['0002_5fuser_5fstudiengang_2epy_2',['0002_user_studiengang.py',['../0002__user__studiengang_8py.html',1,'']]],
  ['0003_5ffriendship_5fpendingfriendrequest_2epy_3',['0003_friendship_pendingfriendrequest.py',['../0003__friendship__pendingfriendrequest_8py.html',1,'']]],
  ['0004_5fuser_5ffriends_5fdelete_5ffriendship_2epy_4',['0004_user_friends_delete_friendship.py',['../0004__user__friends__delete__friendship_8py.html',1,'']]]
];
