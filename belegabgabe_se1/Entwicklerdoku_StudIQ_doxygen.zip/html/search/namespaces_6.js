var searchData=
[
  ['quizzes_0',['quizzes',['../namespacequizzes.html',1,'']]],
  ['quizzes_3a_3aadmin_1',['admin',['../namespacequizzes_1_1admin.html',1,'quizzes']]],
  ['quizzes_3a_3aapps_2',['apps',['../namespacequizzes_1_1apps.html',1,'quizzes']]],
  ['quizzes_3a_3amigrations_3',['migrations',['../namespacequizzes_1_1migrations.html',1,'quizzes']]],
  ['quizzes_3a_3amigrations_3a_3a0001_5finitial_4',['0001_initial',['../namespacequizzes_1_1migrations_1_10001__initial.html',1,'quizzes::migrations']]],
  ['quizzes_3a_3amigrations_3a_3a0002_5falter_5fquizattempt_5funique_5ftogether_5fand_5fmore_5',['0002_alter_quizattempt_unique_together_and_more',['../namespacequizzes_1_1migrations_1_10002__alter__quizattempt__unique__together__and__more.html',1,'quizzes::migrations']]],
  ['quizzes_3a_3amodels_6',['models',['../namespacequizzes_1_1models.html',1,'quizzes']]],
  ['quizzes_3a_3aserializers_7',['serializers',['../namespacequizzes_1_1serializers.html',1,'quizzes']]],
  ['quizzes_3a_3aurls_8',['urls',['../namespacequizzes_1_1urls.html',1,'quizzes']]],
  ['quizzes_3a_3aviews_9',['views',['../namespacequizzes_1_1views.html',1,'quizzes']]]
];
