var searchData=
[
  ['unique_5ftogether_0',['unique_together',['../classmodels_1_1StudyDay_1_1Meta.html#a1d2121ac6283219c4a525d0359c07407',1,'models.StudyDay.Meta.unique_together'],['../classmodels_1_1PendingFriendRequest_1_1Meta.html#af08ac2601fa6a0470682be6d29ace177',1,'models.PendingFriendRequest.Meta.unique_together']]],
  ['urlpatterns_1',['urlpatterns',['../namespaceurls.html#ac7947f6d2f07186c8b516887982cf836',1,'urls.urlpatterns'],['../namespaceconfig_1_1urls.html#ae29049386060d228ee4813d1ba49e289',1,'config.urls.urlpatterns'],['../namespacequizzes_1_1urls.html#a87a650a8b2080b1ca4f08bb0e3a4b500',1,'quizzes.urls.urlpatterns']]],
  ['use_5fi18n_2',['USE_I18N',['../namespaceconfig_1_1settings.html#a7e53571f5b011e85da819b7afc9815c9',1,'config::settings']]],
  ['use_5ftz_3',['USE_TZ',['../namespaceconfig_1_1settings.html#abdedfd8fbaacd872db8ece0ca34db328',1,'config::settings']]],
  ['user_4',['user',['../classmodels_1_1StudyDay.html#ad0fa12d9e4596535f0a7dd433b704182',1,'models.StudyDay.user'],['../classquizzes_1_1models_1_1QuizSession.html#ae22113559757ba255201f7501a5cba31',1,'quizzes.models.QuizSession.user'],['../classquizzes_1_1models_1_1Feedback.html#a53f34bfc7ca8bdab2ec5a94d24055316',1,'quizzes.models.Feedback.user']]],
  ['username_5',['username',['../classserializers_1_1LoginSerializer.html#aa7093e072df4e50fdbeda04c3d6accd4',1,'serializers::LoginSerializer']]]
];
