var searchData=
[
  ['studiq_0',['StudiQ',['../index.html',1,'']]]
];
