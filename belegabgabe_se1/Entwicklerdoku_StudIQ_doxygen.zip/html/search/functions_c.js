var searchData=
[
  ['register_5fstudy_5factivity_0',['register_study_activity',['../namespaceviews.html#ac1b4297d200e2dcb4b8b6aa999462bbc',1,'views']]],
  ['retrieve_1',['retrieve',['../classquizzes_1_1views_1_1ModulViewSet.html#a3907bbea558babad747cf9c97da45ba0',1,'quizzes::views::ModulViewSet']]],
  ['run_5ftests_2',['run_tests',['../classlogging__runner_1_1LoggingTestRunner.html#a6bb11545df26b41e1ac39055cd56c6a4',1,'logging_runner::LoggingTestRunner']]]
];
