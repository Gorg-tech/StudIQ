var searchData=
[
  ['name_0',['name',['../classapps_1_1AccountsConfig.html#ae165cc4de9b310e2d69bff692b803617',1,'apps.AccountsConfig.name'],['../classquizzes_1_1apps_1_1QuizzesConfig.html#a5ec475e21f4a768cb729c995f303cd6a',1,'quizzes.apps.QuizzesConfig.name'],['../classquizzes_1_1models_1_1Studiengang.html#a9467fb74c063a92909124d002abe5e9b',1,'quizzes.models.Studiengang.name'],['../classquizzes_1_1models_1_1Modul.html#a1889b9911e534917fec12f0c436d86c9',1,'quizzes.models.Modul.name'],['../classscraper_1_1apps_1_1ScraperConfig.html#a6233eda1bbe0371a10809e15caa15363',1,'scraper.apps.ScraperConfig.name']]],
  ['new_1',['new',['../QuizResultView_8vue.html#ac7eaa8bf8a5e78a8b7e32cffb6b55bc2',1,'QuizResultView.vue']]],
  ['next_2',['next',['../QuizResultView_8vue.html#adfc67587d0153ed453054f04d35de429',1,'QuizResultView.vue']]]
];
