var searchData=
[
  ['update_0',['update',['../classquizzes_1_1serializers_1_1QuizSerializer.html#a9501541916691fbacb920109079c623d',1,'quizzes.serializers.QuizSerializer.update()'],['../classquizzes_1_1views_1_1QuizViewSet.html#a2613f4a8f90c7d061f320be7f6392cff',1,'quizzes.views.QuizViewSet.update()'],['../classquizzes_1_1views_1_1LernsetViewSet.html#ae4aade0e07fc15085851aeca3e675d60',1,'quizzes.views.LernsetViewSet.update()']]]
];
